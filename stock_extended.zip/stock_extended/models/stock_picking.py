from odoo import models, api


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    @api.onchange('move_ids_without_package')
    def onchange_sale_id(self):
        for records in self:
            if records.move_ids_without_package:
                for moves in records.move_ids_without_package:
                    sale_ids = self.env['stock.picking'].search([('sale_id', '=', self.sale_id.id)])
                    print(f"length =  {len(sale_ids)}")
                    print(f"sale_id = {self.sale_id}, len = {len(self.sale_id)}")
                    if moves.product_id.invoice_policy == "delivery":
                        if moves.quantity_done > 0 and moves.product_uom_qty != moves.quantity_done and len(
                                sale_ids) == 1:
                            self._origin.button_validate()
                            if moves.quantity_done <= moves.product_uom_qty:
                                backorder_confirmation = self.env['stock.backorder.confirmation'].create(
                                    {'pick_ids': records.ids, 'show_transfers': False})

                                backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
                                    'backorder_confirmation_id': backorder_confirmation.id,
                                    'picking_id': backorder_confirmation.pick_ids.id,
                                    'to_backorder': True})
                                self._origin.button_validate()
                                backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()

                        elif len(sale_ids) > 1 and moves.product_uom_qty != moves.quantity_done:
                            self._origin.button_validate()

                            backorder_confirmation = self.env['stock.backorder.confirmation'].create(
                                {'pick_ids': records.ids, 'show_transfers': False})

                            backorder_confirmation_line = self.env['stock.backorder.confirmation.line'].create({
                                'backorder_confirmation_id': backorder_confirmation.id,
                                'picking_id': backorder_confirmation.pick_ids.id,
                                'to_backorder': True})
                            backorder_confirmation.with_context(button_validate_picking_ids=self.ids).process()

                        elif moves.product_uom_qty == moves.quantity_done:
                            self._origin.button_validate()



    # backorder_confirmation.process()
    # sale_ids = self.env['sale.order'].browse(records.sale_id.id)
    # self.env['sale.advance.payment.inv'].create({
    #     'sale_order_ids': sale_ids,
    #     'company_id': sale_ids.company_id.id,
    #     'advance_payment_method': 'delivered'
    # }).create_invoices()
    # context = self.env.context.copy()
    # if not context.get('is_state'):
    #     context.update({'is_state': True})
    #     self.env.context = context
    #     self.state = 'done'

    # def write(self, vals):
    #     res = super(StockPicking, self).write(vals)
    #     for records in self:
    #         if vals.get('move_ids_without_package'):
    #             for moves in vals.get('move_ids_without_package'):
    #                 for y in moves:
    #                     if type(y) is dict:
    #                         if y.get('quantity_done'):
    #                             print(records.move_ids_without_package.product_id.invoice_policy)
    #                             if records.move_ids_without_package.product_id.invoice_policy == "delivery":
    #                                 self.button_validate()
    #                                 backorder_confirmation = self.env['stock.backorder.confirmation'].create({'pick_ids': records.ids})
    #                                 print(f"backorder_confirmation = {backorder_confirmation}")
    #                                 backorder_confirmation.process()
    #                                 self.env['stock.backorder.confirmation.line'].create(
    #                                     {'backorder_confirmation_id' : backorder_confirmation.id, 'picking_id': self.id})
    #                             sale_ids = self.env['sale.order'].browse(records.sale_id.id)
    #                             self.env['sale.advance.payment.inv'].create({
    #                                 'sale_order_ids': sale_ids,
    #                                 'company_id': sale_ids.company_id.id,
    #                                 'advance_payment_method': 'delivered'
    #                             }).create_invoices()
    #                         context = self.env.context.copy()
    #                         if not context.get('is_state'):
    #                             context.update({'is_state': True})
    #                             self.env.context = context
    #     return res
