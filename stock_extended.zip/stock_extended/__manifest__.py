{
    'name': 'Stock Extended',
    'version': '16.1',
    'depends': ['stock', 'sale_management']
}