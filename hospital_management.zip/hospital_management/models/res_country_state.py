from odoo import models, fields, api


class HospitalState(models.Model):
    _inherit = "res.country.state"

    total_hospitals = fields.Integer(compute="_compute_total_hospitals")

    def action_view_hospitals(self):
        action = self.env['ir.actions.act_window']._for_xml_id('hospital_management.hospital_state_action_2')
        hospital_id = self.env['res.country.state'].search([('id', '=', self.id)], limit=1)
        action["domain"] = [("state_id", "=", hospital_id.id)]
        return action

    def _compute_total_hospitals(self):
        for records in self:
            records.total_hospitals = self.env['hospital.data'].search_count([('state_id', '=', records.id)])
